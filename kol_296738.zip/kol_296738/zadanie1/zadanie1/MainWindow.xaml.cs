﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadanie1
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void b2_Click(object sender, RoutedEventArgs e)
        {
            b2.Background = Brushes.Green;
        }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            b1.Background = Brushes.Green;
        }

        private void b3_Click(object sender, RoutedEventArgs e)
        {
            b3.Background = Brushes.Green;
        }

        private void b4_Click(object sender, RoutedEventArgs e)
        {
            b4.Background = Brushes.Green;
        }

        private void b5_Click(object sender, RoutedEventArgs e)
        {
            b5.Background = Brushes.Green;
        }
    }
}
